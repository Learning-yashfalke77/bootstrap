from django.contrib import messages
from django.shortcuts import redirect, render
from django.contrib.auth.models import User, auth


def sign_up(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password = request.POST['password']
        cpassword = request.POST['cpassword']
        email = request.POST['email']

        if password == cpassword:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Username Taken')
                return redirect('/accounts/sign-up')
            elif User.objects.filter(email=email).exists():
                messages.info(request, 'E-mail already exists')
                return redirect('/accounts/sign-up')
            elif first_name.isalpha() == False:
                messages.info(request, 'Name should be letters only')
                return redirect('/accounts/sign-up')
            elif last_name.isalpha() == False:
                messages.info(request, 'Name should be letters only')
                return redirect('/accounts/sign-up')
            else:
                user = User.objects.create_user(
                    username=username, password=password, email=email, first_name=first_name, last_name=last_name)
                user.save()
                return redirect('/accounts/sign-in')
        else:
            messages.info(request, 'Password not matching')
            return redirect('/accounts/sign-up')
    else:
        return render(request, 'sign up.html')


def sign_in(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username= username, password= password)
        if user is not None:
            auth.login(request, user)
            return redirect("/")
        else:
            messages.info(request, 'invalid credentials')
            return redirect('/accounts/sign-in')

    else:
        return render(request, 'login.html')


def logout(request):
    auth.logout(request)
    return redirect('/')

