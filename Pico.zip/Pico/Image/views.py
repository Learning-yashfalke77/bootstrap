from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import Image, Category
from django.contrib.auth.decorators import login_required
# Create your views here.


def index(request):
    images = Image.objects.all()
    categories = Category.objects.all()

    return render(request, 'index.html', {'images': images, 'categories': categories})


def viewImage(request, pk):
    images = Image.objects.get(id=pk)
    return render(request, 'view image.html', {'images': images})


def category(request, category):
    images = Image.objects.filter(category=category)
    categories = Category.objects.all()
    return render(request, 'category.html', {'images': images, 'categories': categories})


def search(request):
    picture = request.GET['picture']
    images = Image.objects.filter(tags__icontains = picture)
    categories = Category.objects.all()
    return render(request, 'search.html', {'images': images, 'picture': picture, 'categories': categories})


@login_required(login_url = "/accounts/sign-in")
def upload(request):
    if request.method == 'POST':
        data = request.POST
        images = request.FILES.get('images')
       
        if data['category'] != None:
            category = Category.objects.get(id = data['category'])
        
        images = Image.objects.create(
            category = category,
            tags = data['tags'],
            image = images
        )
        return redirect('/thanks')
    else:
        categories = Category.objects.all()
        return render(request, 'upload image.html', {'categories' : categories})


def thanks(request):
    return render(request, 'thanks.html')


@login_required(login_url='/accounts/sign-in')
def profile(request):
    return render(request, 'profile.html')